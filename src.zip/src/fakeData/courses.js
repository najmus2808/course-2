



var courses =
[
{
            "id":0,
            "title": "Node.js: The Complete Guide to Build RESTful APIs (2018)",
            "author": "Najmus",
            "price":9.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1638522_fbdf.jpg"
},
{
            "id":1,
            "title": "RESTful Web services with ASP.NET Core",
            "author": "Sakib",
            "price":10.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1312650_2fc6_2.jpg"
},
{
            "id":2,
            "title": "Vert.x 3.5 Java API's Fast and Simple",
            "author": "Imran",
            "price":15.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1657036_087a_2.jpg"
},
{
            "id":3,
            "title": "Loopback 4: Modern ways to Build APIs in Typescript & NodeJs",
            "author": "Afzal",
            "price":19.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1523066_334c_13.jpg"
},
{
            "id":4,
            "title": "Learn Restful Api's with .Net Core 3.1",
            "author": "Fakhrul",
            "price":12.99,
            "img":"https://img-a.udemycdn.com/course/240x135/2768924_a14b_5.jpg"
},
{
            "id":5,
            "title": "ASP.NET CORE and C# REST API With Real World Projects",
            "author": "Fahim",
            "price":14.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1257336_364b_6.jpg"
},
{
            "id":6,
            "title": "NestJs: Modern ways to build APIs with Typescript and NestJs",
            "author": "Jahid",
            "price":17.99,
            "img":"https://img-a.udemycdn.com/course/240x135/2555702_cf7b_6.jpg"
},
{
            "id":7,
            "title": "Asp.Net Core : The Complete Guide To Build Rest Api's",
            "author": "Ucchas",
            "price":18.99,
            "img":"https://img-a.udemycdn.com/course/240x135/2556116_2c61_5.jpg"
},
{
            "id":8,
            "title": "Java:spring restful web service crud",
            "author": "Rashed",
            "price":22.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1131052_a07c.jpg"
},
{
            "id":9,
            "title": "Building RESTful APIs with Go",
            "author": "Rakib",
            "price":21.99,
            "img":"https://img-a.udemycdn.com/course/240x135/2136218_e961_4.jpg"
},
{
            "id":10,
            "title": "Learn Restful webservices/API testing with real time project",
            "author": "Munna",
            "price":12.99,
            "img":"https://img-a.udemycdn.com/course/240x135/995164_630f_2.jpg"
},
{
            "id":11,
            "title": "RESTful Web API Design with Node.js - Second Edition",
            "author": "Mahir",
            "price":9.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1176312_558c_2.jpg"
},
{
            "id":12,
            "title": "ASP.NET Core: Build a RESTful API - Create & Consume (2020)",
            "author": "Sadhin",
            "price":13.99,
            "img":"https://img-a.udemycdn.com/course/240x135/3403072_34bd_3.jpg"
},
{
            "id":13,
            "title": "Desenvolvendo REST / RESTful APIs com Ruby on Rails",
            "author": "Zalal",
            "price":15.99,
            "img":"https://img-a.udemycdn.com/course/240x135/1082928_b432_3.jpg"
},
{
            "id":14,
            "title": "Fastify + MongoDB, desarrolla tu propia RESTFUL API",
            "author": "Nazrul",
            "price":9.99,
            "img":"https://img-a.udemycdn.com/course/240x135/2276501_7257.jpg"
}

];

export default courses;

